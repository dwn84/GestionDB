/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author s203e32
 */
public class Pacientes {
    
    private String PacId;
    private String PacNombre;
    private String PacApellido;
    private String pacFechaNacimiento;
    private String PacSexo;

    /**
     * @return the PacId
     */
    public String getPacId() {
        return PacId;
    }

    /**
     * @param PacId the PacId to set
     */
    public void setPacId(String PacId) {
        this.PacId = PacId;
    }

    /**
     * @return the PacNombre
     */
    public String getPacNombre() {
        return PacNombre;
    }

    /**
     * @param PacNombre the PacNombre to set
     */
    public void setPacNombre(String PacNombre) {
        this.PacNombre = PacNombre;
    }

    /**
     * @return the PacApellido
     */
    public String getPacApellido() {
        return PacApellido;
    }

    /**
     * @param PacApellido the PacApellido to set
     */
    public void setPacApellido(String PacApellido) {
        this.PacApellido = PacApellido;
    }

    /**
     * @return the pacFechaNacimiento
     */
    public String getPacFechaNacimiento() {
        return pacFechaNacimiento;
    }

    /**
     * @param pacFechaNacimiento the pacFechaNacimiento to set
     */
    public void setPacFechaNacimiento(String pacFechaNacimiento) {
        this.pacFechaNacimiento = pacFechaNacimiento;
    }

    /**
     * @return the PacSexo
     */
    public String getPacSexo() {
        return PacSexo;
    }

    /**
     * @param PacSexo the PacSexo to set
     */
    public void setPacSexo(String PacSexo) {
        this.PacSexo = PacSexo;
    }
}
