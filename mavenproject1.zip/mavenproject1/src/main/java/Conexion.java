
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author s203e32
 */
public class Conexion {
    
    
    public static Connection abrirConexion(){
    
        Connection connection = null;
        String connectionUrl =
                "jdbc:sqlserver://B14_203_32\\SQLEXPRESS:1433;"
                        + "database=DBTratamientos;"
                        + "user=otroUsuario;"
                        + "password=123456;"
                        + "encrypt=True;"
                        + "trustServerCertificate=true;"
                        + "loginTimeout=30;";
         
         try{
            connection = DriverManager.getConnection(connectionUrl);
            return connection;
        }
        // Handle any errors that may have occurred.
        catch (SQLException e) {  
            JOptionPane.showMessageDialog(null, e.getMessage());
            return null;
        }
    }
    
}
