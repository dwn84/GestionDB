
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author s203e32
 */
public class GestorPaciente {

    private Connection con;
    private ArrayList<Pacientes> listaPacientes;

    public GestorPaciente() {

        con = Conexion.abrirConexion();
        listaPacientes = new ArrayList<>();
        if (con == null) {
            JOptionPane.showMessageDialog(null, "Error en la conexión a la BD, contacte al administrador. Error código 0x0001: " );
        }
    }

    public boolean agregarPaciente(Pacientes pac) {
        
        String sql = "Insert into tblPacientes values(?,?,?,?,?);";
        try {
            PreparedStatement preSQLInsert = con.prepareStatement(sql);
            preSQLInsert.setString(1, pac.getPacId());
            preSQLInsert.setString(2, pac.getPacNombre());
            preSQLInsert.setString(3, pac.getPacApellido());
            preSQLInsert.setString(4, pac.getPacFechaNacimiento());
            preSQLInsert.setString(5, pac.getPacSexo());
            preSQLInsert.execute();
            return true;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en la ejecución, contacte al administrador. Error código 0x0002" + e.getMessage());
            return false;
        }

    }
    public boolean actualizarPaciente(Pacientes pac) {
        //update...
        return true;
    
    }
    
     public boolean eliminarPaciente(String Idpac) {
        //delete... where IdPac= ?
        return true;
    
    }
    public ArrayList<Pacientes> listarPacientes() {
        String sql = "select * from tblPacientes;";
        ResultSet resultadoConsulta;
        try {
            Statement comandoSQL = con.createStatement();
            resultadoConsulta = comandoSQL.executeQuery(sql);
            Pacientes miPaciente;
            listaPacientes.clear();
            while(resultadoConsulta.next()){
                miPaciente =  new Pacientes();
                miPaciente.setPacId(resultadoConsulta.getString(1));
                miPaciente.setPacNombre(resultadoConsulta.getString(2));
                miPaciente.setPacApellido(resultadoConsulta.getString(3));
                miPaciente.setPacFechaNacimiento(resultadoConsulta.getString(4));
                miPaciente.setPacSexo(resultadoConsulta.getString(5));
                listaPacientes.add(miPaciente);                
            }
            return listaPacientes;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en la ejecución, contacte al administrador. Error código 0x0003" + e.getMessage());
            return null;
        }

    }

    /**
     * @return the listaPacientes
     */
    
}
